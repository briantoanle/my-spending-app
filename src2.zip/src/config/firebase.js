// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth,GoogleAuthProvider} from "firebase/auth";
import { getFirestore } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyCcKXzDvfytX9THrOdZvz_WZmWfYCSjBnE",
  authDomain: "myapp-63005.firebaseapp.com",
  projectId: "myapp-63005",
  storageBucket: "myapp-63005.firebasestorage.app",
  messagingSenderId: "169188263412",
  appId: "1:169188263412:web:05229c3eecab5a422e25a1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const db = getFirestore(app)